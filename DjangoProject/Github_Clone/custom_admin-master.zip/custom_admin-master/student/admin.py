from django.contrib import admin

from student import models
# Register your models here.


admin.site.register(models.Account)