from django.apps import AppConfig


class BeeflowConfig(AppConfig):
    name = 'beeflow'
