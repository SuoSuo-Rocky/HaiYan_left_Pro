#!/usr/bin/env python
# -*- coding:utf-8 -*-
import re

print(re.match('^/customer/list/$', '/customer/list/'))
